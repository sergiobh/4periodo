/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.ads.factory;

/**
 *
 * @author Vericio
 */
public class BDFactory {
    String tipoBD;
    
    public Driver
    
    
}
            
        
        //return null;
    

