/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.una.ads.dropbox.questao5;

/**
 *
 * @author edgard.cardoso
 */
public class Busca {
    
}
